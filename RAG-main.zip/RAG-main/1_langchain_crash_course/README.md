Langchain crash course
=======================
Install necessary modules by running following command
```commandline
pip install -r requirements.txt
```

langchain_crashcourse.ipynb contains the notebook in the video tutorial on codebasics YouTube channel

RestaurantNameGenerator folder contain the streamlit app the generates restaurand name based on the cuisine and also the food items in that restaurant
